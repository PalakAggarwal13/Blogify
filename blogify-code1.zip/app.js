require("dotenv").config();

const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const cookieParser = require('cookie-parser');
const Blog = require('./models/blog');

const app = express();
const PORT = process.env.PORT || 8000;

const userRoute = require('./routes/user');
const blogRoute = require('./routes/blog');
const { checkForauthenticationCookie ,requireAuth} = require('./middlewares/authentication');

mongoose.connect(process.env.MONGO_URL).then(e=> console.log("MongoDB Connected..."));

app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cookieParser());
app.use(checkForauthenticationCookie("token"));

app.use(express.static(path.resolve('./public')));
app.use('/user',userRoute);
app.use('/blog',blogRoute);

app.set('view engine','ejs');
app.set('views',path.resolve('./views'));

app.get("/",async (req,res)=>{
    const allBlogs = await Blog.find({});
    res.render('home',{
        user : req.user,
        blogs : allBlogs,
    });
});


app.listen(PORT,()=>console.log(`Server Started at PORT: ${PORT}`));